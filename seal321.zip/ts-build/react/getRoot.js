"use strict";
/**
 * Created by cyrilluce on 2016/8/15.
 */
const React = require("react");
const mobx_react_1 = require("mobx-react");
const ItemDb_1 = require("./containers/ItemDb");
function getRoot(store) {
    return React.createElement(mobx_react_1.Provider, { store: store },
        React.createElement(ItemDb_1.default, null));
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = getRoot;
