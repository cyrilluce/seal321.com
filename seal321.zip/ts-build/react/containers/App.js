"use strict";
/**
 * Created by cyrilluce on 2016/8/14.
 */
const React = require("react");
const react_1 = require("react");
const react_redux_1 = require("react-redux");
class App extends react_1.Component {
    render() {
        // Injected by connect() call:
        const { dispatch } = this.props;
        return (React.createElement("div", null, "Empty App"));
    }
}
// Which props do we want to inject, given the global state?
// Note: use https://github.com/faassen/reselect for better performance.
function select(state) {
    return {};
}
Object.defineProperty(exports, "__esModule", { value: true });
// 包装 component ，注入 dispatch 和 state 到其默认的 connect(select)(App) 中；
exports.default = react_redux_1.connect(select)(App);
