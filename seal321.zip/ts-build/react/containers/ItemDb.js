"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * Created by cyrilluce on 2016/8/14.
 */
const React = require("react");
const react_1 = require("react");
const mobx_react_1 = require("mobx-react");
const SearchBar_1 = require("../components/SearchBar");
const SearchList_1 = require("../components/SearchList");
const ItemDetail_1 = require("../components/ItemDetail");
const ReactPaginate = require("react-paginate");
let ReactPaginateFix = ReactPaginate;
let ItemDb = class ItemDb extends react_1.Component {
    handlePageClick(page) {
        // react-paginate的page对象selected属性是0-base
        this.props.store.paginate(page.selected + 1);
    }
    render() {
        // Injected by connect() call:
        const { store } = this.props;
        const state = this.state || {};
        const { paginationExpanded } = state;
        const { keyword, page, pageSize, list, totalCount, pageCount, searching } = store;
        return React.createElement("div", { className: "container-fluid" },
            React.createElement("h1", null, "\u7269\u54C1\u6570\u636E\u5E93 v2.0 Beta"),
            React.createElement(SearchBar_1.default, { keyword: keyword, onSearch: keyword => store.search(keyword) }),
            React.createElement(ReactPaginateFix, { previousLabel: "«", nextLabel: "»", breakLabel: React.createElement("a", { href: "#", onClick: () => { this.setState({ paginationExpanded: true }); } }, "..."), 
                // breakLabel="..."
                breakClassName: "break", forcePage: page - 1, pageCount: pageCount, marginPagesDisplayed: paginationExpanded ? 999 : 2, pageRangeDisplayed: paginationExpanded ? 999 : 5, onPageChange: this.handlePageClick.bind(this), containerClassName: "pagination", activeClassName: "active" }),
            React.createElement(SearchList_1.default, { onItemClick: item => { store.viewItem(item); } }),
            React.createElement(ReactPaginateFix, { previousLabel: "«", nextLabel: "»", breakLabel: React.createElement("a", { href: "#", onClick: () => { this.setState({ paginationExpanded: true }); } }, "..."), 
                // breakLabel="..."
                breakClassName: "break", forcePage: page - 1, pageCount: pageCount, marginPagesDisplayed: paginationExpanded ? 999 : 2, pageRangeDisplayed: paginationExpanded ? 999 : 5, onPageChange: this.handlePageClick.bind(this), containerClassName: "pagination", activeClassName: "active" }),
            totalCount > 0 && React.createElement("p", null,
                "\u5171",
                totalCount,
                "\u6761\u8BB0\u5F55"),
            React.createElement(ItemDetail_1.default, null));
    }
};
ItemDb = __decorate([
    mobx_react_1.inject('store'),
    mobx_react_1.observer
], ItemDb);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ItemDb;
