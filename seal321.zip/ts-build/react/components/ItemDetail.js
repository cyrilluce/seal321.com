"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
const React = require("react");
const mobx_react_1 = require("mobx-react");
const Draggable = require("react-draggable");
const util_1 = require("../util");
const types_1 = require("../../types");
const models_1 = require("../../models");
const lang = require("../../lang");
const AddLevelTools_1 = require("./AddLevelTools");
/** 玩家总结的是水晶=1PT，但实际上水晶的价值为2 */
const crystalPoint = 2;
let ItemDetail = class ItemDetail extends React.Component {
    constructor() {
        super(...arguments);
        this.lastPos = { x: 50, y: 50 };
    }
    /** 渲染职业需求 */
    renderJobs(jobs, isBattlePet) {
        if (isBattlePet) {
            return jobs.map(job => lang.BattlePetJobNames[job]);
        }
        if (jobs.some(job => job === types_1.Job.ALL)) {
            return '适合所有职业使用';
        }
        jobs = jobs.filter(job => job !== types_1.Job.GAME_MASTER);
        if (!jobs.length) {
            return '禁止任何职业使用';
        }
        return jobs.map(job => lang.JobNames[job]);
    }
    render() {
        const { store } = this.props;
        const { item, itemLevel } = store;
        if (!item) {
            return React.createElement("noscript", null);
        }
        const itemModel = new models_1.ItemModel(item, itemLevel);
        // 是否为精炼模拟模式
        const addMode = itemLevel > 0;
        const additional = itemModel.additional;
        // return  <Draggable><div>testestset</div></Draggable>;
        return React.createElement(Draggable, { handle: ".handler", bounds: "parent", defaultPosition: this.lastPos, onStop: (e, data) => { this.lastPos = data; } },
            React.createElement("div", { className: "item-popover" },
                React.createElement("img", { className: "item-popover-close glyphicon glyphicon-off", src: "/images/close.png", onClick: () => { store.viewItem(null); } }),
                React.createElement("div", { className: "row handler" },
                    React.createElement("div", { className: "col-xs-12" },
                        React.createElement("p", { className: "text-center" },
                            React.createElement("strong", null, "\u5E0C\u5C14\u7279\u56FD\u5BB6\u5730\u7406 \u7269\u54C1\u67E5\u770B")))),
                React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-2" },
                        React.createElement("div", { className: "icon" },
                            React.createElement("div", { style: util_1.getIconStyle(item.displayid) }))),
                    React.createElement("div", { className: "col-xs-10" },
                        React.createElement("p", { className: "item-popover-name" },
                            React.createElement("strong", null,
                                item.name,
                                " ",
                                addMode && `+${itemModel.addLevel}`)),
                        itemModel.maxAddLevel > 0 && React.createElement(AddLevelTools_1.default, { setLevel: level => store.setItemLevel(level), level: itemLevel, maxLevel: itemModel.maxAddLevel }),
                        React.createElement("div", { className: "row no-gutter" },
                            React.createElement("div", { className: "col-xs-5 no-wrap" },
                                "\u7C7B\u522B\uFF1A",
                                lang.ItemTypeNames[item.type] || '未知'),
                            itemModel.equipable && React.createElement("div", { className: "col-xs-7 no-wrap" },
                                "\u88C5\u5907\u4F4D\u7F6E\uFF1A",
                                lang.EquipPositionNames[item.posid] || '未知')))),
                React.createElement("div", { className: "row no-gutter item-property" },
                    item.type === types_1.ItemType.FOOD && [
                        item.cure_hp !== 0 && React.createElement("div", { key: "cure_hp", className: "col-xs-6 no-wrap" },
                            "\u6062\u590DHP ",
                            item.cure_hp),
                        item.cure_ap !== 0 && React.createElement("div", { key: "cure_ap", className: "col-xs-6 no-wrap" },
                            "\u6062\u590DAP ",
                            item.cure_ap)
                    ],
                    item.type !== types_1.ItemType.TASK && item.type !== types_1.ItemType.CHEST && item.type !== types_1.ItemType.CHEST_KEY && item.type !== types_1.ItemType.CHEST_VIP && [
                        (item.attack !== 0 || item.attack_step !== 0) && React.createElement("div", { key: "attack", className: "col-xs-6 no-wrap" },
                            "\u653B\u51FB\u529B ",
                            item.attack + additional.attack,
                            addMode || `(${item.attack_step})`),
                        (item.magic !== 0 || item.magic_step !== 0) && React.createElement("div", { key: "magic", className: "col-xs-6 no-wrap" },
                            "\u9B54\u6CD5\u529B ",
                            item.magic + additional.magic,
                            addMode || `(${item.magic_step})`),
                        (item.defense !== 0 || item.defense_step !== 0) && React.createElement("div", { key: "defense", className: "col-xs-6 no-wrap" },
                            "\u9632\u5FA1\u529B ",
                            item.defense + additional.defense,
                            addMode || `(${item.defense_step})`),
                        item.attackspeed !== 0 && React.createElement("div", { key: "attackspeed", className: "col-xs-6 no-wrap" },
                            "\u653B\u51FB\u901F\u5EA6 ",
                            item.attackspeed),
                        item.critical !== 0 && React.createElement("div", { key: "critical", className: "col-xs-6 no-wrap" },
                            "\u5FC5\u6740\u6280 ",
                            item.critical),
                        item.accuracy !== 0 && React.createElement("div", { key: "accuracy", className: "col-xs-6 no-wrap" },
                            "\u547D\u4E2D\u7387 ",
                            item.accuracy),
                        item.evade !== 0 && React.createElement("div", { key: "evade", className: "col-xs-6 no-wrap" },
                            "\u56DE\u907F\u7387 ",
                            item.evade),
                        item.demageinc !== 0 && React.createElement("div", { key: "demageinc", className: "col-xs-6 no-wrap" },
                            "\u589E\u52A0\u4F24\u5BB3\u529B ",
                            item.demageinc + additional.demageinc,
                            "%"),
                        item.demagedec !== 0 && React.createElement("div", { key: "demagedec", className: "col-xs-6 no-wrap" },
                            "\u51CF\u5C11\u4F24\u5BB3\u529B ",
                            item.demagedec + additional.demagedec,
                            "%"),
                        item.movespeed !== 0 && React.createElement("div", { key: "movespeed", className: "col-xs-6 no-wrap" },
                            "\u79FB\u52A8\u901F\u5EA6 ",
                            item.movespeed),
                    ],
                    item.type === types_1.ItemType.TASK && [
                        item.task_fame !== 0 && React.createElement("div", { key: "task_fame", className: "col-xs-6 no-wrap" },
                            "\u83B7\u5F97\u58F0\u671B ",
                            item.task_fame),
                        item.magic !== 0 && React.createElement("div", { key: "magic", className: "col-xs-6 no-wrap" },
                            "\u83B7\u5F97\u7ECF\u9A8C ",
                            item.magic),
                        item.task_res2 !== 0 && React.createElement("div", { key: "task_res2", className: "col-xs-6 no-wrap" },
                            "\u83B7\u5F97\u91D1\u94B1 ",
                            item.task_res2),
                    ],
                    item.type !== types_1.ItemType.FOOD && [
                        item.cure_hp !== 0 && React.createElement("div", { key: "cure_hp", className: "col-xs-6 no-wrap" },
                            "HP\u63D0\u9AD8 ",
                            item.cure_hp),
                        item.cure_ap !== 0 && React.createElement("div", { key: "cure_ap", className: "col-xs-6 no-wrap" },
                            "AP\u63D0\u9AD8 ",
                            item.cure_ap),
                    ]),
                React.createElement("div", { className: "row no-gutter item-require" }, itemModel.equipable && [
                    item.jobid !== 0 && React.createElement("div", { key: "jobs", className: "col-xs-12" }, this.renderJobs(itemModel.jobs, item.type === types_1.ItemType.BATTLE_PET_EQUIPMENT)),
                    (item.level !== 0 || item.level_step !== 0) && React.createElement("div", { key: "level", className: "col-xs-12 no-wrap" },
                        "\u7B49\u7D1A\u9650\u5236 ",
                        item.level + additional.level,
                        addMode || `(${item.level_step})`),
                    item.fame !== 0 && React.createElement("div", { key: "fame", className: "col-xs-12 no-wrap" },
                        "\u58F0\u671B\u9650\u5236 ",
                        item.fame),
                    (item.needstrength !== 0 || item.needstrength_step !== 0) && React.createElement("div", { key: "needstrength", className: "col-xs-6 no-wrap" },
                        "\u529B\u91CF ",
                        item.needstrength + additional.needstrength,
                        addMode || `(${item.needstrength_step})`),
                    (item.needagile !== 0 || item.needagile_step !== 0) && React.createElement("div", { key: "needagile", className: "col-xs-6 no-wrap" },
                        "\u654F\u6377 ",
                        item.needagile + additional.needagile,
                        addMode || `(${item.needagile_step})`),
                    (item.needwisdom !== 0 || item.needwisdom_step !== 0) && React.createElement("div", { key: "needwisdom", className: "col-xs-6 no-wrap" },
                        "\u667A\u529B ",
                        item.needwisdom + additional.needwisdom,
                        addMode || `(${item.needwisdom_step})`),
                    (item.needvit !== 0 || item.needvit_step !== 0) && React.createElement("div", { key: "needvit", className: "col-xs-6 no-wrap" },
                        "\u4F53\u529B ",
                        item.needvit + additional.needvit,
                        addMode || `(${item.needvit_step})`),
                    (item.needint !== 0 || item.needint_step !== 0) && React.createElement("div", { key: "needint", className: "col-xs-6 no-wrap" },
                        "\u7CBE\u795E ",
                        item.needint + additional.needint,
                        addMode || `(${item.needint_step})`),
                    (item.needluck !== 0 || item.needluck !== 0) && React.createElement("div", { key: "needluck", className: "col-xs-6 no-wrap" },
                        "\u611F\u89C9 ",
                        item.needluck + additional.needluck,
                        addMode || `(${item.needluck_step})`),
                ]),
                !itemModel.description && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" }, item.description)),
                itemModel.description && React.createElement("div", { className: "row" },
                    itemModel.description.properties.map((str, index) => React.createElement("div", { key: index, className: "col-xs-12 item-require" }, str)),
                    React.createElement("div", { className: "col-xs-12 item-description" }, itemModel.description.description)),
                item.buyprice !== 0 && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" },
                        "\u8D2D\u4E70\u4EF7\u683C - ",
                        item.buyprice + additional.buyprice,
                        "s")),
                item.sellprice !== 0 && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" },
                        "\u51FA\u552E\u4EF7\u683C - ",
                        item.sellprice + additional.sellprice,
                        "s")),
                item.type === types_1.ItemType.ITEM_PET && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" },
                        "\u5BA0\u7269\u9700\u6C42\u7ECF\u9A8C - ",
                        item.petpoint + additional.petpoint)),
                item.type !== types_1.ItemType.ITEM_PET && item.petpoint !== 0 && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" },
                        "\u5582\u517B\u503C - ",
                        item.petpoint)),
                item.type === types_1.ItemType.GEM && React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-xs-12 item-description" },
                        "PT - ",
                        item.pt / crystalPoint)),
                item.type !== types_1.ItemType.GEM && itemModel.gAssistable && React.createElement("div", { className: "row no-gutter" },
                    addMode && React.createElement("div", { className: "col-xs-12 item-description" }, itemLevel in itemModel.ptTable ? `PT - ${itemModel.ptTable[itemLevel] / crystalPoint}` : `（精炼等级不足，无法作为G辅助材料）`),
                    !addMode && React.createElement("div", { className: "col-xs-12 item-pt-table" },
                        React.createElement("span", null, "\u5404\u7B49\u7D1APT\u503C\u8868"),
                        this.renderPtTable(itemModel.ptTable, false))),
                itemModel.equipable && (item.g_item !== 0 || item.t_item !== 0 || item.s_item !== 0 || item.c_item !== 0) && React.createElement("div", { className: "row no-gutter" },
                    addMode && React.createElement("div", { className: "col-xs-12 item-description" }, itemLevel in itemModel.ptNeedTable ? `G化所需PT - ${Math.round(itemModel.ptNeedTable[itemLevel] * 100 / crystalPoint) / 100}` : `（精炼等级不足，无法G化）`),
                    !addMode && React.createElement("div", { className: "col-xs-12 item-pt-table" },
                        React.createElement("span", null, "\u5404\u7B49\u7D1AG\u5316\u6240\u9700PT\u503C\u8868"),
                        this.renderPtTable(itemModel.ptNeedTable, true)))));
    }
    renderPtTable(ptTable, isNeedTable) {
        const levels = isNeedTable ? [7, 8, 9, 10, 11, 12] : [5, 6, 7, 8, 9, 10, 11, 12];
        return React.createElement("table", null,
            React.createElement("tbody", null,
                React.createElement("tr", null,
                    React.createElement("td", null, "\u7B49\u7D1A"),
                    levels.map(level => React.createElement("td", { key: level }, level))),
                React.createElement("tr", null,
                    React.createElement("td", null, isNeedTable ? '需PT' : 'PT值'),
                    levels.map(level => React.createElement("td", { key: level }, Math.round(ptTable[level] / crystalPoint * 100) / 100)))));
    }
};
ItemDetail = __decorate([
    mobx_react_1.inject('store'),
    mobx_react_1.observer
], ItemDetail);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ItemDetail;
