/**
 * 列表
 * Created by cyrilluce on 2016/8/14.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
const React = require("react");
const react_1 = require("react");
const mobx_react_1 = require("mobx-react");
const SearchItem_1 = require("./SearchItem");
let SearchList = class SearchList extends react_1.Component {
    onItemClick(index) {
        const { onItemClick, store } = this.props;
        if (onItemClick) {
            onItemClick(store.list[index]);
        }
    }
    render() {
        const { onItemClick, store } = this.props;
        let content, message, cls;
        if (store.searching) {
        }
        else if (!store.totalCount) {
            message = store.keyword ? `未查到匹配“${store.keyword}”的物品` : '请输入关键字开始搜索物品';
        }
        else if (!store.list.length) {
            message = '此页无数据';
        }
        content = store.list.map((data, index) => React.createElement(SearchItem_1.default, { data: data, key: index, onClick: this.onItemClick.bind(this, index) }));
        return (React.createElement("table", { className: "item-list table table-striped table-condensed table-hover" },
            React.createElement("colgroup", null,
                React.createElement("col", { style: { minWidth: "40px", width: "5%" } }),
                React.createElement("col", { style: { minWidth: "260px", width: "20%" } }),
                React.createElement("col", { style: { minWidth: "100px", width: "15%" } }),
                React.createElement("col", { style: { minWidth: "100px", width: "10%" } }),
                React.createElement("col", { style: { maxWidth: "300px", width: "50%" } })),
            React.createElement("thead", null,
                React.createElement("tr", null,
                    React.createElement("th", null),
                    React.createElement("th", null, "\u540D\u79F0"),
                    React.createElement("th", null, "\u7C7B\u522B"),
                    React.createElement("th", null, "\u7B49\u7EA7"),
                    React.createElement("th", null, "\u63CF\u8FF0"))),
            React.createElement("tbody", null,
                message && React.createElement("tr", { className: "active" },
                    React.createElement("td", { colSpan: 5 },
                        React.createElement("p", { className: "text-center" }, message))),
                content)));
    }
};
SearchList = __decorate([
    mobx_react_1.inject('store'),
    mobx_react_1.observer
], SearchList);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SearchList;
