"use strict";
const React = require("react");
class ItemLink extends React.Component {
}
exports.ItemLink = ItemLink;
