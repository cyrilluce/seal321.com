/**
 * 搜索栏
 * Created by cyrilluce on 2016/8/14.
 */
"use strict";
const React = require("react");
const react_1 = require("react");
const react_dom_1 = require("react-dom");
class SearchBar extends react_1.Component {
    render() {
        return (React.createElement("div", { className: "row" },
            React.createElement("div", { className: "col-lg-6 col-md-6 col-sm-9 col-xs-12" },
                React.createElement("div", { className: "input-group" },
                    React.createElement("span", { className: "input-group-addon" }, "\u7269\u54C1\u540D\u79F0\uFF1A"),
                    React.createElement("input", { ref: "input", type: "text", className: "form-control", size: 50, placeholder: "输入物品名称后回车搜索", defaultValue: this.props.keyword, "aria-describedby": "basic-addon1", onChange: () => { }, onKeyUp: this.handleEnter.bind(this) }),
                    React.createElement("span", { className: "input-group-btn" },
                        React.createElement("button", { className: "btn btn-default", type: "button", onClick: this.doSearch.bind(this) },
                            React.createElement("span", { className: "glyphicon glyphicon-search", "aria-hidden": "true" }),
                            " \u641C\u7D22"))))));
    }
    handleEnter(e) {
        if (e.which === 13) {
            this.doSearch();
        }
    }
    doSearch() {
        const refs = this.refs;
        const node = react_dom_1.findDOMNode(refs['input']);
        const text = node.value.trim();
        this.props.onSearch(text);
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SearchBar;
