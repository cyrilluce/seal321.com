/**
 * 搜索结果条目
 * Created by cyrilluce on 2016/8/14.
 */
"use strict";
const React = require("react");
const react_1 = require("react");
const util_1 = require("../util");
const lang = require("../../lang");
class SearchItem extends react_1.Component {
    onClick() {
        const { data, onClick } = this.props;
        if (onClick) {
            onClick(data);
        }
    }
    render() {
        const { data } = this.props;
        return React.createElement("tr", { className: "item", onClick: this.onClick.bind(this) },
            React.createElement("td", null,
                React.createElement("div", { className: "noselect", style: util_1.getIconStyle(data.displayid) })),
            React.createElement("td", null, data.name),
            React.createElement("td", null, lang.ItemTypeNames[data.type]),
            React.createElement("td", null, data.level || '-'),
            React.createElement("td", null, data.description));
        // return (
        //     <li onClick={this.onClick.bind(this)}>
        //         <div style={getIconStyle(data.displayid)} />
        //         {data.name}
        //     </li>
        // )
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SearchItem;
