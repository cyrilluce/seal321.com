"use strict";
const server_1 = require("react-dom/server");
const mobx_react_1 = require("mobx-react");
const mobx_1 = require("mobx");
const getRoot_1 = require("../react/getRoot");
const config = require("../config");
const db_1 = require("../stores/db");
// 防止mobx内存泄漏
mobx_react_1.useStaticRendering(true);
// 接下来会补充这部分代码
function handleRender(req, res) {
    const store = new db_1.default({
        keyword: req.query.keyword,
        page: +req.query.page
    });
    // 如果store加载完成（服务端加载），则渲染之
    mobx_1.when('加载完成', () => store.initialized, () => {
        const state = mobx_1.toJS(store);
        res.render("index", {
            // 把组件渲染成字符串
            html: server_1.renderToString(getRoot_1.default(store)),
            development: process.env.NODE_ENV === 'development',
            state,
            staticPath: process.env.NODE_ENV === 'development' ? `http://127.0.0.1:${config.localHotLoadPort}` : ''
        });
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = handleRender;
