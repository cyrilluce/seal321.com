"use strict";
function success(data = undefined) {
    return {
        success: true,
        data
    };
}
exports.success = success;
function failure(msg = "请求出错") {
    return {
        success: false,
        msg
    };
}
exports.failure = failure;
