"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const mysql_1 = require("../../lib/mysql");
const logger_1 = require("../../logger");
const util_1 = require("../util");
const promisify_1 = require("../../util/promisify");
function constrain(v, min, max) {
    v = v || 0;
    v = Math.max(min, v);
    v = Math.min(max, v);
    return v;
}
function default_1(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const query = req.body;
        const table = "item";
        const { loc: db, keyword = "", offset = 0, limit = 20 } = query;
        // 模糊搜索
        const keywordSearch = '%' + keyword.replace(/(%_)/g, '\\$1') + '%';
        logger_1.default.info('搜索', keyword, offset, limit);
        const tableName = `seal_${db}_${table}`;
        let conn;
        try {
            conn = yield mysql_1.getConnectionAsync();
            const queryAsync = promisify_1.default(conn.query, conn);
            const [data, countData] = yield Promise.all([
                queryAsync(`SELECT * FROM ${tableName} WHERE name like ? limit ?,?`, [keywordSearch, constrain(offset, 0, 1000000), constrain(limit, 0, 100)]),
                queryAsync(`SELECT count(*) as count FROM ${tableName} WHERE name like ?`, [keywordSearch])
            ]);
            res.json(util_1.success({
                list: data,
                count: countData[0] && countData[0].count || 0
            }));
        }
        catch (err) {
            logger_1.default.error('query/list', err);
            res.json(util_1.failure(err.message));
        }
        finally {
            if (conn) {
                conn.release();
            }
        }
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
