"use strict";
const express = require("express");
const config_1 = require("../../config");
const util_1 = require("../util");
const list_1 = require("./list");
let router = express.Router();
// 统一校验，服务器、db
router.use(function (req, res, next) {
    const loc = req.body.loc || config_1.mainDb;
    if (!(loc in config_1.dbs)) {
        return res.json(util_1.failure('无此主数据库'));
    }
    req.body.loc = loc;
    next();
});
router.use('/list', list_1.default);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = router;
