"use strict";
const types_1 = require("../../types");
exports.JobNames = {
    [types_1.Job.BEGINNER]: "初学者",
    [types_1.Job.WARRIOR]: "剑士",
    [types_1.Job.KNIGHT]: "骑士",
    [types_1.Job.JESTER]: "小丑",
    [types_1.Job.MAGE]: "法师",
    [types_1.Job.PRIEST]: "祭司",
    [types_1.Job.CRAFTSMAN]: "铁匠",
    [types_1.Job.GAME_MASTER]: "GM",
    [types_1.Job.ALL]: "所有职业",
    [types_1.Job.BERSERKER]: "狂剑士",
    [types_1.Job.SWORD_MASTER]: "魔剑士",
    [types_1.Job.RENEGADE]: "暗骑士",
    [types_1.Job.DEFENDER]: "圣骑士",
    [types_1.Job.ASSASSIN]: "刺客",
    [types_1.Job.GAMBLER]: "艺者",
    [types_1.Job.ICE_WIZARD]: "冰魔导",
    [types_1.Job.FIRE_WIZARD]: "炎魔导",
    [types_1.Job.TEMPLAR]: "审判者",
    [types_1.Job.APOSTLE]: "圣贤者",
    [types_1.Job.DEMOLITIONIST]: "爆破士",
    [types_1.Job.ARTISAN]: "匠师",
    [types_1.Job.HUNTER]: "獵人",
    [types_1.Job.ARCHER]: "弓箭手",
    [types_1.Job.GUNNER]: "槍手",
    [types_1.Job.COOK]: "饕客",
    [types_1.Job.CHEF]: "食神",
    [types_1.Job.FOOD_FIGHTER]: "美食家"
};
exports.BattlePetJobNames = {
    [types_1.BattlePetJob.LIGHT]: "光精灵",
    [types_1.BattlePetJob.DARK]: "暗精灵",
    [types_1.BattlePetJob.FIRE]: "火精灵",
    [types_1.BattlePetJob.WATER]: "水精灵",
};
