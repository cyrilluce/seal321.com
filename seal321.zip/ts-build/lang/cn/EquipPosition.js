"use strict";
const types_1 = require("../../types");
exports.EquipPositionNames = {
    [types_1.EquipPosition.HEAD]: "头",
    [types_1.EquipPosition.TOP]: "上衣",
    [types_1.EquipPosition.BOTTOM]: "裤子",
    [types_1.EquipPosition.SHOE]: "鞋子",
    [types_1.EquipPosition.MAIN_HAND]: "主武器",
    [types_1.EquipPosition.SUB_HAND]: "副手",
    [types_1.EquipPosition.APPEND]: "饰品",
    [types_1.EquipPosition.PET]: "宠物",
};
