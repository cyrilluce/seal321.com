"use strict";
const fetch_1 = require("../util/fetch");
/**
 * 查询物品列表
 */
function list(param) {
    return fetch_1.default('/node/query/list', param);
}
exports.list = list;
