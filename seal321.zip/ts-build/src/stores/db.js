"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
// 物品数据库store
// TODO 如何解决reaction进行中的判断？用于服务端判断是否加载完成
const mobx_1 = require("mobx");
const query = require("./query");
const delay_1 = require("../util/delay");
class ItemDbStore {
    constructor(options = {}, skipReaction = false) {
        // ------------------- 原始属性 --------------------
        /**
         * 错误信息
         */
        this.message = "";
        /**
         * 是否处于搜索状态
         */
        this.searching = false;
        /**
         * 搜索出的物品列表
         */
        this.list = [];
        /**
         * 搜索出的物品总数
         */
        this.totalCount = 0;
        /**
         * 搜索关键字
         */
        this.keyword = "";
        /**
         * 当前页码
         */
        this.page = 1;
        /**
         * 当前页面大小
         */
        this.pageSize = 15;
        /** 当前查看的物品的模拟等级 */
        this.itemLevel = 0;
        if (!skipReaction) {
            this.initReactions();
        }
        const { keyword = "", page, pageSize } = options;
        if (keyword) {
            this.search(keyword);
        }
        if (page) {
            this.paginate(+page, +pageSize);
        }
    }
    /**
     * 初始化Reactions
     */
    initReactions() {
        this.reactionSearch();
    }
    /**
     * 用于前端进行store复原
     */
    static fromJS(data) {
        const store = new ItemDbStore(undefined, true);
        Object.keys(data).forEach(key => {
            if (key in store) {
                store[key] = data[key];
            }
        });
        store.initReactions();
        return store;
    }
    // ------------------- 高级属性 ----------------
    /**
     * 是否初始化结束（用于服务端渲染判断）
     */
    get initialized() {
        return !this.searching;
    }
    /**
     * 总页数
     */
    get pageCount() {
        return Math.ceil(this.totalCount / this.pageSize) || 1;
    }
    /**
     * 起始位置
     */
    get offset() {
        return (this.page - 1) * this.pageSize;
    }
    /**
     * 拉取数量
     */
    get limit() {
        return this.pageSize;
    }
    // ------------------- 动作 --------------------
    /**
     * 搜索
     */
    search(keyword) {
        this.keyword = keyword;
        this.page = 1; // 搜索时，重置页码
    }
    /**
     * 翻页
     */
    paginate(page, pageSize) {
        this.page = page;
        if (pageSize) {
            this.pageSize = pageSize;
        }
    }
    /**
     * 查看物品
     */
    viewItem(item, level = 0) {
        this.item = item;
        this.itemLevel = level;
    }
    /** 设置精炼等级 */
    setItemLevel(level) {
        // 装备、宠物才可以精练
        level = Math.max(0, level);
        level = Math.min(12, level);
        this.itemLevel = level;
    }
    // ------------------ 响应 Reactions ---------------------
    /**
     * 响应搜索
     */
    reactionSearch() {
        let token = 1;
        mobx_1.reaction('搜索', () => ({
            keyword: this.keyword,
            offset: this.offset,
            limit: this.limit
        }), (params) => __awaiter(this, void 0, void 0, function* () {
            let list, totalCount;
            const myToken = ++token;
            if (params.keyword) {
                // 搜索
                this.searching = true;
                // 缓冲
                yield delay_1.default();
                // 如果重复执行了，本次取消，类似于debounce？
                if (myToken !== token) {
                    return;
                }
                try {
                    let data = yield query.list(params);
                    if (myToken !== token) {
                        return;
                    }
                    list = data.list;
                    totalCount = data.count;
                }
                catch (err) {
                    list = [];
                    totalCount = 0;
                    this.message = err.message || JSON.stringify(err);
                }
            }
            else {
                list = [];
                totalCount = 0;
            }
            // 搜索结束
            this.list = list;
            this.totalCount = totalCount;
            this.searching = false;
        }));
    }
}
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "message", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "searching", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "list", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "totalCount", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "keyword", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "page", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "pageSize", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "item", void 0);
__decorate([
    mobx_1.observable
], ItemDbStore.prototype, "itemLevel", void 0);
__decorate([
    mobx_1.computed
], ItemDbStore.prototype, "initialized", null);
__decorate([
    mobx_1.computed
], ItemDbStore.prototype, "pageCount", null);
__decorate([
    mobx_1.computed
], ItemDbStore.prototype, "offset", null);
__decorate([
    mobx_1.computed
], ItemDbStore.prototype, "limit", null);
__decorate([
    mobx_1.action
], ItemDbStore.prototype, "search", null);
__decorate([
    mobx_1.action
], ItemDbStore.prototype, "paginate", null);
__decorate([
    mobx_1.action
], ItemDbStore.prototype, "viewItem", null);
__decorate([
    mobx_1.action
], ItemDbStore.prototype, "setItemLevel", null);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ItemDbStore;
