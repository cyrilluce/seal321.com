"use strict";
const redux_1 = require("redux");
// 把action type与reducer合并写？
// 用户操作
exports.SEARCH = 'SEARCH'; // 搜索
exports.PAGING = 'PAGING'; // 翻页
exports.DETAIL = 'DETAIL'; // 查看物品详情
// 内部操作
exports.SEARCH_START = 'SEARCH_START';
exports.INITIAL = 'INITIAL'; // 初始化，如果已初始化，则浏览器端不再初始化
exports.SET_READY = 'SET_READY'; // 设置加载完成状态
// 异步操作前后缀 --- TODO 待定
exports.ASYNC_PREFIX = 'FETCH';
exports.ASYNC_SUFFIXS = {
    START: '_START',
    DONE: '_DONE',
    FAIL: '_FAIL'
};
exports.fetchStart = type => [exports.ASYNC_PREFIX, type, exports.ASYNC_SUFFIXS.START].join('_');
// action creator
exports.search = keyword => ({ type: exports.SEARCH, value: keyword });
exports.paging = (page, size) => ({ type: exports.PAGING, page, size });
// reducers
const staticReducer = (state = null) => state;
const createAsyncReducer = (type, initValue) => {
    return redux_1.combineReducers({
        loading: (state = false, action) => {
            const subType = action.type.slice(type.length);
            switch (subType) {
                case exports.ASYNC_SUFFIXS.START:
                    return true;
                case exports.ASYNC_SUFFIXS.DONE:
                case exports.ASYNC_SUFFIXS.FAIL:
                    return false;
                default:
                    return state;
            }
        },
        data: (state = initValue, action) => {
            const subType = action.type.slice(type.length);
            switch (subType) {
                case exports.ASYNC_SUFFIXS.DONE:
                    return action.value;
                default:
                    return state;
            }
        },
        error: (state = null, action) => {
            const subType = action.type.slice(type.length);
            switch (subType) {
                case exports.ASYNC_SUFFIXS.FAIL:
                    return action.value;
                default:
                    return state;
            }
        }
    });
};
const reducers = {
    // 初始path
    path: staticReducer,
    // 初始params
    params: staticReducer,
    // 是否进行过初始化
    initialized: (state = false, action) => {
        switch (action.type) {
            case exports.INITIAL:
                return true;
            default:
                return state;
        }
    },
    // 当前页面是否处于加载完成状态
    ready: (state = false, action) => {
        switch (action.type) {
            case exports.SET_READY:
                return action.value;
            default:
                return state;
        }
    },
    // 搜索关键字
    keyword: (state = '', action) => {
        switch (action.type) {
            case exports.SEARCH:
                return action.value;
            default:
                return state;
        }
    },
    // 是否处于搜索状态
    searching: (state = false, action) => {
        switch (action.type) {
            case exports.SEARCH:
                return true;
            default:
                return state;
        }
    },
    // 分页信息
    page: (state = 1, action) => {
        switch (action.type) {
            case exports.SEARCH:
                return 1;
            case exports.PAGING:
                return action.page || state;
            default:
                return state;
        }
    },
    // 页面大小
    size: (state = 20, action) => {
        switch (action.type) {
            case exports.PAGING:
                return action.size || state;
            default:
                return state;
        }
    },
    // 搜索结果
    result: createAsyncReducer(exports.SEARCH, { total: 0, list: [] })
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = reducers;
