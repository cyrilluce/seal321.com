"use strict";
const redux_1 = require("redux");
const redux_saga_1 = require("redux-saga");
const createLogger = require("redux-logger");
const sagas_1 = require("./sagas");
const actions_1 = require("./actions");
// store factory
function getStore(initialState) {
    // create the saga middleware
    const sagaMiddleware = redux_saga_1.default();
    // mount it on the Store
    const store = redux_1.createStore(redux_1.combineReducers(actions_1.default), initialState, process.env.NODE_ENV === 'development' ?
        redux_1.applyMiddleware(sagaMiddleware, createLogger()) :
        redux_1.applyMiddleware(sagaMiddleware));
    // then run the saga
    sagaMiddleware.run(sagas_1.default);
    return store;
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = getStore;
