"use strict";
const redux_saga_1 = require("redux-saga");
const effects_1 = require("redux-saga/effects");
const types = require("./actions");
require("babel-polyfill");
const url_1 = require("url");
const config = require("../config");
///<reference path="../types/global.d.ts" />
// 异步加载
function fetch(path, params) {
    if (global.IS_BROWSER) {
        return new Promise((resolve, reject) => {
            window.jQuery.ajax({
                url: path,
                data: params,
                type: 'post',
                dataType: 'json'
            }).then(json => {
                if (!json.success) {
                    return reject(json);
                }
                resolve(json.data);
            }, reject);
            // resolve({
            //     total : 100,
            //     list : [
            //         {
            //             name : '物品a'
            //         }
            //     ]
            // })
        });
    }
    else {
        // 这里判断如果是本服务，可以自动加上sessionId
        return require('node-fetch')(url_1.resolve(`http://${config.deployServer}`, path), {
            method: 'POST',
            body: JSON.stringify(params)
        }).then(res => res.json()).then(json => {
            if (!json.success) {
                throw json;
            }
            return json.data;
        });
    }
}
// 包装一下，防止说没有catch报错
function wrap(promise) {
    return promise.then(data => ({ data }), err => ({ err }));
}
// 标记为loading，但设计为异步，如果立即完成了，则并不会loading
function* markLoading(type) {
    yield redux_saga_1.delay(0);
    yield effects_1.put({
        type: type + types.ASYNC_SUFFIXS.START
    });
}
// 以某actionType为基础进行异步任务请求
function* fetchWith(type, promise) {
    const task = yield effects_1.fork(markLoading, type);
    const { data, err } = yield wrap(promise);
    yield effects_1.cancel(task);
    if (err) {
        yield effects_1.put({
            type: type + types.ASYNC_SUFFIXS.FAIL,
            value: err
        });
        return;
    }
    yield effects_1.put({
        type: type + types.ASYNC_SUFFIXS.DONE,
        value: data
    });
}
// 执行搜索
function* doSearch() {
    const { keyword, page, size } = yield effects_1.select();
    yield fetchWith(types.SEARCH, fetch('/node/query/list', {
        keyword,
        page,
        size
    }));
}
// TODO 执行翻页
// TODO 执行查看详情
function* init() {
    const { initialized, keyword } = yield effects_1.select();
    if (initialized) {
        return;
    }
    // 初始化
    if (keyword) {
        yield effects_1.put({ type: types.SEARCH, value: keyword });
    }
    yield redux_saga_1.delay(0);
    yield effects_1.put({ type: types.INITIAL });
}
function* rootSaga() {
    yield [
        // 搜索联动
        redux_saga_1.takeLatest([types.SEARCH, types.PAGING], doSearch),
        // 初始化
        init()
    ];
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = rootSaga;
