// import promisify from './promisify';
"use strict";
// export default promisify(function(delay, cb){
//     setTimeout(cb, delay);
// });
function delay(ms = 0) {
    return new Promise(resolve => {
        setTimeout(resolve, ms);
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = delay;
