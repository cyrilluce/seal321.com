"use strict";
function promisify(fn, host) {
    return function (...args) {
        return new Promise((resolve, reject) => {
            args.push((err, result) => {
                if (err) {
                    reject(err);
                    return;
                }
                resolve(result);
            });
            fn.apply(host, args);
        });
    };
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = promisify;
