"use strict";
function* test() {
}
function cancelable(generator) {
    return function () {
        let iterator = generator();
        let result;
        do {
            result = iterator.next();
            if (Array.isArray(result)) {
            }
        } while (!result.done);
    };
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = cancelable;
