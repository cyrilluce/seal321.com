"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const config = require("../config");
const isomorphicFetch = require("isomorphic-fetch");
/**
 * 异步加载
 * @param path 请求相对路径
 * @param params 请求参数，对象，以json格式传给后台
 */
function fetch(path, params) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!global.IS_BROWSER) {
            path = require('url').resolve(`http://${config.deployServer}`, path);
        }
        // 这里判断如果是本服务，可以自动加上sessionId
        let res = yield isomorphicFetch(path, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(params)
        });
        let json = yield res.json();
        if (!json.success) {
            throw json;
        }
        return json.data;
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = fetch;
