"use strict";
/**
 * Created by cyrilluce on 2016/8/7.
 */
const logger_1 = require("./logger");
const http = require("http");
const web_1 = require("./routers/web");
const config = require("./config");
process.on('unhandledrejection', (reason, p) => {
    logger_1.default.error("Unhandled Rejection at: Promise ", p, " reason: ", reason);
    throw reason;
});
// process.on('uncaughtException', function(e){
//     logger.error(e);
//     logger.error(e.stack);
// });
// 发布工具
let deployRouter = require('./routers/deploy');
http.createServer(deployRouter).listen(config.deployPort, '0.0.0.0', function () {
    logger_1.default.info('远程发布服务监听于 ', config.deployPort);
});
web_1.default.listen(config.nginxWebPort, '0.0.0.0', () => {
    logger_1.default.info('Web服务监听于', config.nginxWebPort);
});
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = web_1.default;
