"use strict";
/** 物品类型 */
var ItemType;
(function (ItemType) {
    /** 普通物品 */
    ItemType[ItemType["NORMAL"] = 0] = "NORMAL";
    /** 恢复药品 */
    ItemType[ItemType["FOOD"] = 1] = "FOOD";
    /** 无数据 */
    ItemType[ItemType["UNKNOW2"] = 2] = "UNKNOW2";
    /** 特殊物品（药水、经验+） */
    ItemType[ItemType["SPECIAL"] = 3] = "SPECIAL";
    /** 单手剑 */
    ItemType[ItemType["WEAPON_KNIGHT"] = 4] = "WEAPON_KNIGHT";
    /** 时光 */
    ItemType[ItemType["TIME"] = 5] = "TIME";
    /** 双手剑 */
    ItemType[ItemType["WEAPON_WARRIOR"] = 6] = "WEAPON_WARRIOR";
    /** 匕首 */
    ItemType[ItemType["WEAPON_JESTER"] = 7] = "WEAPON_JESTER";
    /** 双手槌 */
    ItemType[ItemType["WEAPON_CRAFTSMAN"] = 8] = "WEAPON_CRAFTSMAN";
    /** 锤 */
    ItemType[ItemType["WEAPON_PRIEST"] = 9] = "WEAPON_PRIEST";
    /** 法杖 */
    ItemType[ItemType["WEAPON_MAGE"] = 11] = "WEAPON_MAGE";
    /** 商城装备 */
    ItemType[ItemType["CASH_EQUIPMENT"] = 12] = "CASH_EQUIPMENT";
    /** 商城套装 */
    ItemType[ItemType["CASH_SET"] = 13] = "CASH_SET";
    /** 盾 */
    ItemType[ItemType["ITEM_SHEILD"] = 14] = "ITEM_SHEILD";
    /** 上衣 */
    ItemType[ItemType["ITEM_CLOTH_KNIGHT"] = 15] = "ITEM_CLOTH_KNIGHT";
    /** 上衣 */
    ItemType[ItemType["ITEM_CLOTH"] = 16] = "ITEM_CLOTH";
    /** 帽子 */
    ItemType[ItemType["ITEM_HAT"] = 17] = "ITEM_HAT";
    /** 也是帽子 */
    ItemType[ItemType["ITEM_HAT_2"] = 18] = "ITEM_HAT_2";
    /** 鞋子 */
    ItemType[ItemType["ITEM_SHOES_KNIGHT"] = 19] = "ITEM_SHOES_KNIGHT";
    /** 鞋子 */
    ItemType[ItemType["ITEM_SHOES"] = 20] = "ITEM_SHOES";
    /** 饰品类 */
    ItemType[ItemType["ITEM_ACCESSORY"] = 21] = "ITEM_ACCESSORY";
    /** 宠物 */
    ItemType[ItemType["ITEM_PET"] = 22] = "ITEM_PET";
    /** 宝石类 */
    ItemType[ItemType["GEM"] = 23] = "GEM";
    /** 任务物品 */
    ItemType[ItemType["TASK"] = 24] = "TASK";
    /** 骑士裤子 */
    ItemType[ItemType["ITEM_TROUSERS_KNIGHT"] = 25] = "ITEM_TROUSERS_KNIGHT";
    /** 裤子 */
    ItemType[ItemType["ITEM_TROUSERS"] = 26] = "ITEM_TROUSERS";
    /** 合成/制作书 */
    ItemType[ItemType["BOOK"] = 27] = "BOOK";
    /** 无数据 */
    ItemType[ItemType["UNKNOW28"] = 28] = "UNKNOW28";
    /** *魔剑士武器 */
    ItemType[ItemType["WEAPON_BERSERKER"] = 29] = "WEAPON_BERSERKER";
    /** *狂剑士武器 */
    ItemType[ItemType["WEAPON_SWORDMASTER"] = 30] = "WEAPON_SWORDMASTER";
    /** 暗骑士武器 */
    ItemType[ItemType["WEAPON_RENEGADE"] = 31] = "WEAPON_RENEGADE";
    /** 圣骑士武器 */
    ItemType[ItemType["WEAPON_DEFENDER"] = 32] = "WEAPON_DEFENDER";
    /** 刺客武器 */
    ItemType[ItemType["WEAPON_ASSASSIN"] = 33] = "WEAPON_ASSASSIN";
    /** 艺者武器 */
    ItemType[ItemType["WEAPON_GAMBLER"] = 34] = "WEAPON_GAMBLER";
    /** 冰魔导武器 */
    ItemType[ItemType["WEAPON_ICEWIZARD"] = 35] = "WEAPON_ICEWIZARD";
    /** 炎魔导武器 */
    ItemType[ItemType["WEAPON_FIREWIZARD"] = 36] = "WEAPON_FIREWIZARD";
    /** 审判者武器 */
    ItemType[ItemType["WEAPON_TEMPLAR"] = 37] = "WEAPON_TEMPLAR";
    /** 圣贤者武器 */
    ItemType[ItemType["WEAPON_APOSTLE"] = 38] = "WEAPON_APOSTLE";
    /** 爆破士武器 */
    ItemType[ItemType["WEAPON_DEMOLITIONIST"] = 39] = "WEAPON_DEMOLITIONIST";
    /** 匠师武器 */
    ItemType[ItemType["WEAPON_ARTISAN"] = 40] = "WEAPON_ARTISAN";
    /** 宝箱 */
    ItemType[ItemType["CHEST"] = 41] = "CHEST";
    /** 钥匙 */
    ItemType[ItemType["CHEST_KEY"] = 42] = "CHEST_KEY";
    /** 魔法锁 */
    ItemType[ItemType["CHEST_VIP"] = 43] = "CHEST_VIP";
    /** 绑定饰品 */
    ItemType[ItemType["ACCESSORY_BIND"] = 44] = "ACCESSORY_BIND";
    /** 一次性投掷物 */
    ItemType[ItemType["THROWABLE"] = 45] = "THROWABLE";
    /** 猎人武器 */
    ItemType[ItemType["WEAPON_HUNTER"] = 46] = "WEAPON_HUNTER";
    /** 弓箭手武器 */
    ItemType[ItemType["WEAPON_ARCHER"] = 47] = "WEAPON_ARCHER";
    /** 枪手武器 */
    ItemType[ItemType["WEAPON_GAUNNER"] = 48] = "WEAPON_GAUNNER";
    /** 战宠 */
    ItemType[ItemType["BATTLE_PET"] = 49] = "BATTLE_PET";
    /** 战宠装备 */
    ItemType[ItemType["BATTLE_PET_EQUIPMENT"] = 50] = "BATTLE_PET_EQUIPMENT";
    /** 饕客武器 */
    ItemType[ItemType["WEAPON_COOK"] = 51] = "WEAPON_COOK";
    /** 食神武器 */
    ItemType[ItemType["WEAPON_CHEF"] = 52] = "WEAPON_CHEF";
    /** 美食家武器 */
    ItemType[ItemType["WEAPON_FOOD_FIGHTER"] = 53] = "WEAPON_FOOD_FIGHTER";
})(ItemType = exports.ItemType || (exports.ItemType = {}));
/** G化类型 */
var GType;
(function (GType) {
    /** 其它物品 */
    GType[GType["NORMAL"] = 0] = "NORMAL";
    /** 武器制作书 */
    GType[GType["WEAPON_BOOK"] = 1] = "WEAPON_BOOK";
    /** 武器 */
    GType[GType["WEAPON"] = 2] = "WEAPON";
    /** 防具制作书 */
    GType[GType["ARMOUR_BOOK"] = 3] = "ARMOUR_BOOK";
    /** 防具 */
    GType[GType["ARMOUR"] = 4] = "ARMOUR";
    /** 饰品制作书 */
    GType[GType["ACCESSORY_BOOK"] = 5] = "ACCESSORY_BOOK";
    /** 饰品 */
    GType[GType["ACCESSORY"] = 6] = "ACCESSORY";
    /** 未知7 */
    GType[GType["UNKNOW7"] = 7] = "UNKNOW7";
    /** 未知8 */
    GType[GType["UNKNOW8"] = 8] = "UNKNOW8";
    /** 炼金（炸弹、车）制作书 */
    GType[GType["ALCHEMY_BOOK"] = 9] = "ALCHEMY_BOOK";
    /** 未知10 */
    GType[GType["UNKNOW10"] = 10] = "UNKNOW10";
    /** 战宠、其它特殊装备制作书 */
    GType[GType["BATTLE_PET_EQUIPMENT_BOOK"] = 11] = "BATTLE_PET_EQUIPMENT_BOOK";
    /** 伦石制作书 */
    GType[GType["RUNE_STONE_BOOK"] = 12] = "RUNE_STONE_BOOK";
    /** 未知13 */
    GType[GType["UNKNOW13"] = 13] = "UNKNOW13";
    /** 自然石制作书 */
    GType[GType["NATURAL_STONE_BOOK"] = 14] = "NATURAL_STONE_BOOK";
})(GType = exports.GType || (exports.GType = {}));
/** 装备位置 */
var EquipPosition;
(function (EquipPosition) {
    /** 头 */
    EquipPosition[EquipPosition["HEAD"] = 0] = "HEAD";
    /** 上衣 */
    EquipPosition[EquipPosition["TOP"] = 1] = "TOP";
    /** 裤子 */
    EquipPosition[EquipPosition["BOTTOM"] = 2] = "BOTTOM";
    /** 鞋子 */
    EquipPosition[EquipPosition["SHOE"] = 3] = "SHOE";
    /** 主武器 */
    EquipPosition[EquipPosition["MAIN_HAND"] = 4] = "MAIN_HAND";
    /** 副手 */
    EquipPosition[EquipPosition["SUB_HAND"] = 5] = "SUB_HAND";
    /** 饰品 */
    EquipPosition[EquipPosition["APPEND"] = 6] = "APPEND";
    /** 宠物 */
    EquipPosition[EquipPosition["PET"] = 7] = "PET";
    /** 耳环 */
    EquipPosition[EquipPosition["EARRING"] = 8] = "EARRING";
    /** 项链 */
    EquipPosition[EquipPosition["NECKLACE"] = 9] = "NECKLACE";
    /** 手镯 */
    EquipPosition[EquipPosition["BRACELET"] = 10] = "BRACELET";
    /** 戒指 */
    EquipPosition[EquipPosition["RING"] = 11] = "RING";
    /** 战宠 */
    EquipPosition[EquipPosition["BATTLE_PET"] = 12] = "BATTLE_PET";
    /** 无法装备 */
    EquipPosition[EquipPosition["NONE"] = 100] = "NONE";
})(EquipPosition = exports.EquipPosition || (exports.EquipPosition = {}));
/** 未知类型1 */
var TypeRes1;
(function (TypeRes1) {
    /** 未知（普通物品、装备、车等） */
    TypeRes1[TypeRes1["UNKNOW0"] = 0] = "UNKNOW0";
    /** 饰品头、配件、手镯、戒指等，无法作为G辅 */
    TypeRes1[TypeRes1["ACCESSORY"] = 1] = "ACCESSORY";
    /** 未知（各种装备） */
    TypeRes1[TypeRes1["UNKNOW2"] = 2] = "UNKNOW2";
    /** 宠物、各种特殊武器 */
    TypeRes1[TypeRes1["SPECIAL_UNKNOW3"] = 3] = "SPECIAL_UNKNOW3";
    /** 未知 几件套装上衣 */
    TypeRes1[TypeRes1["SPECIAL_SET"] = 4] = "SPECIAL_SET";
    /** 未知 西斯帽 */
    TypeRes1[TypeRes1["SPECIAL_PUI_HAT"] = 5] = "SPECIAL_PUI_HAT";
})(TypeRes1 = exports.TypeRes1 || (exports.TypeRes1 = {}));
/** 职业 */
var Job;
(function (Job) {
    /** 初学者 */
    Job[Job["BEGINNER"] = 0] = "BEGINNER";
    /** 剑士 */
    Job[Job["WARRIOR"] = 1] = "WARRIOR";
    /** 骑士 */
    Job[Job["KNIGHT"] = 2] = "KNIGHT";
    /** 小丑 */
    Job[Job["JESTER"] = 3] = "JESTER";
    /** 法师 */
    Job[Job["MAGE"] = 4] = "MAGE";
    /** 祭司 */
    Job[Job["PRIEST"] = 5] = "PRIEST";
    /** 铁匠 */
    Job[Job["CRAFTSMAN"] = 6] = "CRAFTSMAN";
    /** GM */
    Job[Job["GAME_MASTER"] = 7] = "GAME_MASTER";
    /** 所有职业 */
    Job[Job["ALL"] = 8] = "ALL";
    /** 狂剑士 */
    Job[Job["BERSERKER"] = 9] = "BERSERKER";
    /** 魔剑士 */
    Job[Job["SWORD_MASTER"] = 10] = "SWORD_MASTER";
    /** 暗骑士 */
    Job[Job["RENEGADE"] = 11] = "RENEGADE";
    /** 圣骑士 */
    Job[Job["DEFENDER"] = 12] = "DEFENDER";
    /** 刺客 */
    Job[Job["ASSASSIN"] = 13] = "ASSASSIN";
    /** 艺者 */
    Job[Job["GAMBLER"] = 14] = "GAMBLER";
    /** 冰魔导 */
    Job[Job["ICE_WIZARD"] = 15] = "ICE_WIZARD";
    /** 炎魔导 */
    Job[Job["FIRE_WIZARD"] = 16] = "FIRE_WIZARD";
    /** 审判者 */
    Job[Job["TEMPLAR"] = 17] = "TEMPLAR";
    /** 圣贤者 */
    Job[Job["APOSTLE"] = 18] = "APOSTLE";
    /** 爆破士 */
    Job[Job["DEMOLITIONIST"] = 19] = "DEMOLITIONIST";
    /** 匠师 */
    Job[Job["ARTISAN"] = 20] = "ARTISAN";
    /** 獵人 */
    Job[Job["HUNTER"] = 21] = "HUNTER";
    /** 弓箭手 */
    Job[Job["ARCHER"] = 22] = "ARCHER";
    /** 槍手 */
    Job[Job["GUNNER"] = 23] = "GUNNER";
    /** 饕客 */
    Job[Job["COOK"] = 24] = "COOK";
    /** 食神 */
    Job[Job["CHEF"] = 25] = "CHEF";
    /** 美食家 */
    Job[Job["FOOD_FIGHTER"] = 26] = "FOOD_FIGHTER";
})(Job = exports.Job || (exports.Job = {}));
var BattlePetJob;
(function (BattlePetJob) {
    /** 无 */
    BattlePetJob[BattlePetJob["NONE"] = 0] = "NONE";
    /** 光精灵 */
    BattlePetJob[BattlePetJob["LIGHT"] = 1] = "LIGHT";
    /** 暗精灵 */
    BattlePetJob[BattlePetJob["DARK"] = 2] = "DARK";
    /** 火精灵 */
    BattlePetJob[BattlePetJob["FIRE"] = 3] = "FIRE";
    /** 水精灵 */
    BattlePetJob[BattlePetJob["WATER"] = 4] = "WATER";
})(BattlePetJob = exports.BattlePetJob || (exports.BattlePetJob = {}));
/** 属性 */
var Property;
(function (Property) {
    /** 无 */
    Property[Property["NONE"] = 0] = "NONE";
    /** 火 */
    Property[Property["FIRE"] = 1] = "FIRE";
    /** 水 */
    Property[Property["WATER"] = 2] = "WATER";
    /** 木 */
    Property[Property["WOOD"] = 3] = "WOOD";
    /** 金 */
    Property[Property["METAL"] = 4] = "METAL";
    /** 土 */
    Property[Property["MUD"] = 5] = "MUD";
    /** 光 */
    Property[Property["LIGHT"] = 6] = "LIGHT";
    /** 暗 */
    Property[Property["DARK"] = 7] = "DARK";
    /** 魔法 */
    Property[Property["MAGIC"] = 8] = "MAGIC";
    /** 物理 */
    Property[Property["PHYSIC"] = 9] = "PHYSIC";
})(Property = exports.Property || (exports.Property = {}));
