"use strict";
const react_dom_1 = require("react-dom");
const db_1 = require("../stores/db");
const getRoot_1 = require("../react/getRoot");
// 创建新的 Redux store 实例
const store = db_1.default.fromJS(window.__INITIAL_STATE__);
let rootInstance = react_dom_1.render(getRoot_1.default(store), document.getElementById('root'));
if (module.hot) {
    require('react-hot-loader/Injection').RootInstanceProvider.injectProvider({
        getRootInstances: function () {
            // Help React Hot Loader figure out the root component instances on the page:
            return [rootInstance];
        }
    });
}
