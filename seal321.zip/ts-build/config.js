"use strict";
// 本地开发，动态加载端口
exports.localHotLoadPort = 3000;
// 远端服务器地址
exports.deployServer = "beta.seal321.com";
// 远端服务器 发布管理端口
exports.deployPort = 7001;
// 远端服务器 web服务端口
exports.nginxWebPort = 80;
// 默认数据库
exports.mainDb = "tw2";
// MySQL配置
exports.mysql = {
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'seal-v2'
};
// 服务器列表
exports.dbs = {
    "cn": {
        item: 1,
        monster: 1
    },
    "us": {
        item: 1
    },
    "tw2": {
        item: 1
    }
};
